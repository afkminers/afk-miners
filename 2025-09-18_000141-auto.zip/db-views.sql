CREATE OR REPLACE VIEW "public"."player_heroes_snake" AS
SELECT id,
    "playerId" AS player_id,
    "isStarter" AS is_starter,
    name,
    "heroKey" AS hero_key,
    "createdAt" AS created_at
   FROM player_heroes;

CREATE OR REPLACE VIEW "public"."v_hero_skills" AS
SELECT phs.hero_id,
    upper(phs.skill_type) AS skill_type,
    phs.level,
    (COALESCE(phs.tries_progress, (0)::real))::integer AS tries_progress,
    (COALESCE(sc.tries_needed, ((50 * GREATEST(phs.level, 1)))::real))::integer AS tries_needed
   FROM ((player_hero_skills phs
     LEFT JOIN skill_curves sc ON (((sc.skill_type = phs.skill_type) AND (sc.level = (phs.level + 1)))))
     LEFT JOIN weapon_skill_map wsm ON ((wsm.skill_type = phs.skill_type)));

CREATE OR REPLACE VIEW "public"."v_monster_instances" AS
SELECT mi.id,
    mi.monster_id,
    mi.map_key,
    mi.spawn_id,
    mi.max_hp,
    mi.hp,
    mi.state,
    mi.created_at,
    mi.updated_at,
    mi.respawn_at,
    mi.last_hit_hero_id,
    mi.last_hit_at,
    mi.x,
    mi.y,
    mi.hp_max,
    s."monsterKey"
   FROM (monster_instances mi
     JOIN spawns s ON ((s.id = mi.spawn_id)));