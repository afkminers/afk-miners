AFK Miners — Release auto
Gerado em: 2025-09-18 00:02:40
Commit: 2b9a9ca

Arquivos chave:
- API.md, openapi.json → visão dos endpoints
- env-usage.json → variáveis de ambiente usadas
- *db-*.{json,sql,txt} → snapshot do Postgres (schema, counts, indexes, fks, views, triggers, functions, enums, sequences, extensions, sizes)
