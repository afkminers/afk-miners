--
-- PostgreSQL database dump
--

\restrict MBUa9Q7wx1rb8aw5pbqRbUTWcGSzP70UF9bJzdfPNTyzxK73l9ce012DlzLbtf5

-- Dumped from database version 17.5 (a42a079)
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: _touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END
$$;


--
-- Name: _touch_updatedat(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._touch_updatedat() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = now();
  RETURN NEW;
END
$$;


--
-- Name: api_hero_skills(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.api_hero_skills(p_hero_id text) RETURNS TABLE(skill_type text, level integer, tries_progress integer, tries_needed integer)
    LANGUAGE sql STABLE
    AS $$
  SELECT
    v.skill_type,
    v.level,
    v.tries_progress,
    v.tries_needed
  FROM v_hero_skills v
  WHERE v.hero_id = p_hero_id
  ORDER BY v.skill_type;
$$;


--
-- Name: api_hero_skills_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.api_hero_skills_json(p_hero_id text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  SELECT jsonb_build_object(
    'skills',
    COALESCE(
      jsonb_agg(
        jsonb_build_object(
          'skill_type',     s.skill_type,
          'level',          s.level,
          'tries_progress', s.tries_progress,
          'tries_needed',   s.tries_needed
        )
        ORDER BY s.skill_type
      ), '[]'::jsonb
    )
  )
  FROM api_hero_skills(p_hero_id) AS s;
$$;


--
-- Name: ensure_hero_skill_rows(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_hero_skill_rows(p_hero_id text) RETURNS void
    LANGUAGE sql
    AS $$
  INSERT INTO player_hero_skills (hero_id, skill_type, level, tries_progress)
  SELECT p_hero_id, s.skill_type, 1, 0
  FROM (SELECT DISTINCT skill_type FROM skill_curves) s
  LEFT JOIN player_hero_skills phs
         ON phs.hero_id = p_hero_id
        AND phs.skill_type = s.skill_type
  WHERE phs.hero_id IS NULL;
$$;


--
-- Name: items_master_sync_sprite(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.items_master_sync_sprite() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF NEW."dataJSON" ? 'icon' THEN
        NEW.sprite := COALESCE(NEW.sprite, NEW."dataJSON"->>'icon');
      END IF;
      RETURN NEW;
    END$$;


--
-- Name: set_updated_at_generic(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_generic() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      NEW.updated_at := now();
      RETURN NEW;
    END;
    $$;


--
-- Name: tg_ensure_skills_after_hero_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_ensure_skills_after_hero_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM ensure_hero_skill_rows(NEW.id::text);
  RETURN NEW;
END;
$$;


--
-- Name: trg_items_master_sync_sprite(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_items_master_sync_sprite() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."dataJSON" IS NOT NULL THEN
    NEW.name        := COALESCE(NEW."dataJSON"->>'name', NEW.name);
    NEW.slot        := COALESCE(UPPER(NEW."dataJSON"->>'slot'), NEW.slot);
    NEW.kind        := COALESCE(NEW."dataJSON"->>'kind', NEW.kind);
    NEW.weapon_type := COALESCE(NEW."dataJSON"->>'weapon_type', NEW.weapon_type);
    NEW.sprite      := COALESCE(NEW."dataJSON"->>'icon', NEW."dataJSON"->>'sprite', NEW.sprite);
    NEW.atk         := COALESCE((NEW."dataJSON"->>'atk')::int, NEW.atk);
    NEW.def         := COALESCE((NEW."dataJSON"->>'def')::int, NEW.def);
    NEW.slots       := COALESCE((NEW."dataJSON"->>'slots')::int, NEW.slots);
    NEW.stackable   := COALESCE((NEW."dataJSON"->>'stackable')::boolean, NEW.stackable);
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: trg_mi_fix_zero_xy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_mi_fix_zero_xy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- só corrige vivos em (0,0) que tem spawn conhecido
  IF NEW.state = 'ALIVE' AND NEW.x = 0 AND NEW.y = 0 AND NEW.spawn_id IS NOT NULL THEN
    SELECT s.x + FLOOR(random() * GREATEST(s.w, 1)),
           s.y + FLOOR(random() * GREATEST(s.h, 1))
      INTO NEW.x, NEW.y
    FROM spawns s
    WHERE s.id = NEW.spawn_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_mi_log_zero_xy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_mi_log_zero_xy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.state = 'ALIVE' AND NEW.x = 0 AND NEW.y = 0 THEN
    RAISE NOTICE '[mi_zero_xy] id=%, spawn_id=%, at=%, op=%',
      COALESCE(NEW.id::text, 'NULL'),
      COALESCE(NEW.spawn_id::text, 'NULL'),
      now(), TG_OP;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_mi_set_xy_from_spawn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_mi_set_xy_from_spawn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (NEW.x = 0 AND NEW.y = 0) THEN
    SELECT s.x + FLOOR(random()*GREATEST(s.w,1))::int,
           s.y + FLOOR(random()*GREATEST(s.h,1))::int
      INTO NEW.x, NEW.y
    FROM spawns s
    WHERE s.id = NEW.spawn_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_players_set_updatedat(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_players_set_updatedat() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" := now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: afk_boxes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.afk_boxes (
    id text NOT NULL,
    player_id text NOT NULL,
    kind text NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    capacity integer DEFAULT 100 NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: afk_inventories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.afk_inventories (
    player_id text NOT NULL,
    item_type text NOT NULL,
    amount integer DEFAULT 0 NOT NULL
);


--
-- Name: afk_workers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.afk_workers (
    id text NOT NULL,
    player_id text NOT NULL,
    name text NOT NULL,
    produce_type text NOT NULL,
    produce_amount integer DEFAULT 1 NOT NULL,
    rate_sec integer DEFAULT 10 NOT NULL,
    assigned_box text,
    last_collected timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id bigint NOT NULL,
    scope text NOT NULL,
    fromid text,
    fromname text,
    text text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: class_level_gains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_level_gains (
    class text NOT NULL,
    level integer NOT NULL,
    hp_gain integer NOT NULL,
    mana_gain integer NOT NULL,
    cap_gain integer DEFAULT 0
);


--
-- Name: class_skill_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_skill_rates (
    class text NOT NULL,
    skill_type text NOT NULL,
    rate real NOT NULL
);


--
-- Name: class_spells; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_spells (
    class text NOT NULL,
    spell_id text NOT NULL
);


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    name text NOT NULL,
    hp_base integer NOT NULL,
    mana_base integer NOT NULL,
    cap_base integer NOT NULL,
    hp_per_level integer NOT NULL,
    mana_per_level integer NOT NULL,
    cap_per_level integer NOT NULL,
    description text
);


--
-- Name: content_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_files (
    path text NOT NULL,
    checksum text NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: farm_plots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.farm_plots (
    id text NOT NULL,
    player_id text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    crop_key text,
    stage integer DEFAULT 0 NOT NULL,
    planted_at timestamp with time zone,
    next_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: hero_backpack_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_backpack_slots (
    hero_id text NOT NULL,
    slot_index integer NOT NULL,
    item_key text,
    qty integer
);


--
-- Name: hero_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_equipment (
    hero_id uuid NOT NULL,
    slot text NOT NULL,
    item_key text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: hero_last_pos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_last_pos (
    hero_id uuid NOT NULL,
    map_key text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    last_seq bigint DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: hero_loot_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_loot_drops (
    id bigint NOT NULL,
    hero_id uuid NOT NULL,
    monster_instance_id uuid NOT NULL,
    item_key text NOT NULL,
    amount integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    monster_key text
);


--
-- Name: hero_loot_drops_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hero_loot_drops_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hero_loot_drops_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hero_loot_drops_id_seq OWNED BY public.hero_loot_drops.id;


--
-- Name: hero_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_progress (
    hero_id text NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    xp integer DEFAULT 0 NOT NULL,
    hp_max integer DEFAULT 150 NOT NULL,
    mana_max integer DEFAULT 30 NOT NULL,
    hp integer DEFAULT 150 NOT NULL,
    mana integer DEFAULT 30 NOT NULL,
    class text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: hero_training; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_training (
    hero_id text NOT NULL,
    skill_type text,
    status text,
    started_at timestamp with time zone,
    last_tick_at timestamp with time zone,
    energy_current real,
    energy_max real,
    energy_spent real,
    session_seconds integer,
    daily_seconds integer,
    daily_reset_at timestamp with time zone,
    notes text
);


--
-- Name: heroes_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heroes_master (
    id uuid NOT NULL,
    "heroKey" text NOT NULL,
    name text NOT NULL,
    rarity text NOT NULL,
    base_attack integer NOT NULL,
    base_defense integer NOT NULL,
    base_speed integer NOT NULL,
    class text DEFAULT ''::text,
    role text DEFAULT ''::text,
    attack_type text DEFAULT ''::text,
    element text DEFAULT ''::text,
    weapon_pref text DEFAULT ''::text,
    herokey text GENERATED ALWAYS AS ("heroKey") STORED,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    archetype text
);


--
-- Name: items_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items_master (
    id integer NOT NULL,
    key text,
    "dataJSON" jsonb,
    updated_at timestamp with time zone DEFAULT now(),
    name text DEFAULT ''::text NOT NULL,
    slot text DEFAULT 'MISC'::text,
    weapon_type text,
    sprite text,
    atk integer,
    def integer,
    slots integer,
    stackable boolean,
    kind text
);


--
-- Name: items_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.items_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.items_master_id_seq OWNED BY public.items_master.id;


--
-- Name: level_curve; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.level_curve (
    level integer NOT NULL,
    xp_needed bigint NOT NULL
);


--
-- Name: map_loot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_loot (
    id bigint NOT NULL,
    map_key text NOT NULL,
    x integer DEFAULT 0 NOT NULL,
    y integer DEFAULT 0 NOT NULL,
    item_key text NOT NULL,
    qty integer DEFAULT 1 NOT NULL,
    owner_id text,
    dropped_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    "itemsJSON" text
);


--
-- Name: map_loot_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.map_loot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: map_loot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.map_loot_id_seq OWNED BY public.map_loot.id;


--
-- Name: map_loot_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_loot_items (
    loot_id uuid NOT NULL,
    item_key text NOT NULL,
    amount integer NOT NULL,
    CONSTRAINT map_loot_items_amount_check CHECK ((amount > 0))
);


--
-- Name: map_loot_spawns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_loot_spawns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    map_key text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: map_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map_objects (
    id integer NOT NULL,
    "mapKey" text,
    type text,
    x integer,
    y integer,
    w integer,
    h integer,
    "propsJSON" text
);


--
-- Name: map_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.map_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: map_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.map_objects_id_seq OWNED BY public.map_objects.id;


--
-- Name: maps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maps (
    key text NOT NULL,
    "dataJSON" text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: monster_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monster_instances (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    monster_id integer NOT NULL,
    map_key text NOT NULL,
    spawn_id integer NOT NULL,
    max_hp integer NOT NULL,
    hp integer NOT NULL,
    state text DEFAULT 'ALIVE'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    respawn_at timestamp with time zone,
    last_hit_hero_id uuid,
    last_hit_at timestamp with time zone,
    x integer DEFAULT 0,
    y integer DEFAULT 0,
    hp_max integer,
    CONSTRAINT mi_xy_not_zero CHECK (((x <> 0) OR (y <> 0)))
);


--
-- Name: monsters_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monsters_master (
    id integer NOT NULL,
    key text,
    name text,
    xp integer,
    healthmax integer,
    speed integer,
    flagsjson text,
    elementsjson text,
    attacksjson text,
    defensesjson text,
    lootjson text,
    lookjson text,
    updated_at timestamp with time zone DEFAULT now(),
    "healthMax" integer,
    "flagsJSON" jsonb,
    "elementsJSON" jsonb,
    "attacksJSON" jsonb,
    "defensesJSON" jsonb,
    "lootJSON" jsonb,
    "lookJSON" jsonb
);


--
-- Name: monsters_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.monsters_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: monsters_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.monsters_master_id_seq OWNED BY public.monsters_master.id;


--
-- Name: player_hero_equips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_hero_equips (
    hero_id uuid NOT NULL,
    slot text NOT NULL,
    item_key text,
    item_instance_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: player_hero_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_hero_skills (
    hero_id text NOT NULL,
    skill_type text NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    tries_progress real DEFAULT 0 NOT NULL
);


--
-- Name: player_heroes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_heroes (
    id text NOT NULL,
    "heroKey" text NOT NULL,
    name text NOT NULL,
    rarity text NOT NULL,
    attack integer NOT NULL,
    defense integer NOT NULL,
    speed integer NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    "isStarter" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now(),
    "updatedAt" timestamp with time zone DEFAULT now(),
    "playerId" text,
    xp integer DEFAULT 0 NOT NULL,
    hp integer NOT NULL,
    max_hp integer NOT NULL,
    mana integer DEFAULT 50,
    max_mana integer DEFAULT 50,
    alive boolean DEFAULT true,
    last_respawn_at timestamp without time zone,
    death_count integer DEFAULT 0,
    updated_at timestamp with time zone,
    CONSTRAINT player_heroes_hp_check CHECK (((hp >= 0) AND (max_hp >= 1) AND (hp <= max_hp)))
);


--
-- Name: player_heroes_snake; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.player_heroes_snake AS
 SELECT id,
    "playerId" AS player_id,
    "isStarter" AS is_starter,
    name,
    "heroKey" AS hero_key,
    "createdAt" AS created_at
   FROM public.player_heroes;


--
-- Name: player_inventories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_inventories (
    player_id uuid NOT NULL,
    item_key text NOT NULL,
    qty integer DEFAULT 0 NOT NULL
);


--
-- Name: player_last_pos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_last_pos (
    player_id text NOT NULL,
    map_key text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    last_seq bigint DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: player_online; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_online (
    hero_id uuid NOT NULL,
    player_id uuid,
    map_key text,
    last_seen timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: player_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_positions (
    mapkey text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    "playerId" text,
    map text
);


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id text NOT NULL,
    name text NOT NULL,
    password_hash text DEFAULT ''::text,
    coins integer DEFAULT 500 NOT NULL,
    gems integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now(),
    "updatedAt" timestamp with time zone DEFAULT now()
);


--
-- Name: skill_curves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_curves (
    skill_type text NOT NULL,
    level integer NOT NULL,
    tries_needed real NOT NULL
);


--
-- Name: spawns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spawns (
    id integer NOT NULL,
    "mapKey" text,
    "monsterKey" text,
    x integer,
    y integer,
    w integer,
    h integer,
    count integer,
    "respawnSec" integer,
    "levelMin" integer,
    "levelMax" integer,
    CONSTRAINT spawns_monsterkey_not_empty CHECK ((("monsterKey" IS NOT NULL) AND ("monsterKey" <> ''::text)))
);


--
-- Name: spawns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spawns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spawns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spawns_id_seq OWNED BY public.spawns.id;


--
-- Name: spells_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spells_master (
    id text NOT NULL,
    name text NOT NULL,
    min_magic_level integer DEFAULT 1 NOT NULL,
    mana_cost integer DEFAULT 5 NOT NULL,
    base_power integer DEFAULT 12 NOT NULL,
    scaling numeric(6,3) DEFAULT 1.20 NOT NULL,
    element text DEFAULT 'ARCANE'::text NOT NULL
);


--
-- Name: sprites_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprites_master (
    id integer NOT NULL,
    key text,
    kind text,
    "dataJSON" text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: sprites_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sprites_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sprites_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sprites_master_id_seq OWNED BY public.sprites_master.id;


--
-- Name: weapon_skill_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weapon_skill_map (
    weapon_type text NOT NULL,
    skill_type text NOT NULL
);


--
-- Name: v_hero_skills; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_hero_skills AS
 SELECT phs.hero_id,
    upper(phs.skill_type) AS skill_type,
    phs.level,
    (COALESCE(phs.tries_progress, (0)::real))::integer AS tries_progress,
    (COALESCE(sc.tries_needed, ((50 * GREATEST(phs.level, 1)))::real))::integer AS tries_needed
   FROM ((public.player_hero_skills phs
     LEFT JOIN public.skill_curves sc ON (((sc.skill_type = phs.skill_type) AND (sc.level = (phs.level + 1)))))
     LEFT JOIN public.weapon_skill_map wsm ON ((wsm.skill_type = phs.skill_type)));


--
-- Name: v_monster_instances; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_monster_instances AS
 SELECT mi.id,
    mi.monster_id,
    mi.map_key,
    mi.spawn_id,
    mi.max_hp,
    mi.hp,
    mi.state,
    mi.created_at,
    mi.updated_at,
    mi.respawn_at,
    mi.last_hit_hero_id,
    mi.last_hit_at,
    mi.x,
    mi.y,
    mi.hp_max,
    s."monsterKey"
   FROM (public.monster_instances mi
     JOIN public.spawns s ON ((s.id = mi.spawn_id)));


--
-- Name: xp_curves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.xp_curves (
    level integer NOT NULL,
    xp_to_next integer NOT NULL
);


--
-- Name: xp_table; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.xp_table (
    level integer NOT NULL,
    xp_required bigint NOT NULL
);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: hero_loot_drops id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_loot_drops ALTER COLUMN id SET DEFAULT nextval('public.hero_loot_drops_id_seq'::regclass);


--
-- Name: items_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items_master ALTER COLUMN id SET DEFAULT nextval('public.items_master_id_seq'::regclass);


--
-- Name: map_loot id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot ALTER COLUMN id SET DEFAULT nextval('public.map_loot_id_seq'::regclass);


--
-- Name: map_objects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_objects ALTER COLUMN id SET DEFAULT nextval('public.map_objects_id_seq'::regclass);


--
-- Name: monsters_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monsters_master ALTER COLUMN id SET DEFAULT nextval('public.monsters_master_id_seq'::regclass);


--
-- Name: spawns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns ALTER COLUMN id SET DEFAULT nextval('public.spawns_id_seq'::regclass);


--
-- Name: sprites_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_master ALTER COLUMN id SET DEFAULT nextval('public.sprites_master_id_seq'::regclass);


--
-- Name: afk_boxes afk_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_boxes
    ADD CONSTRAINT afk_boxes_pkey PRIMARY KEY (id);


--
-- Name: afk_inventories afk_inventories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_inventories
    ADD CONSTRAINT afk_inventories_pkey PRIMARY KEY (player_id, item_type);


--
-- Name: afk_workers afk_workers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_workers
    ADD CONSTRAINT afk_workers_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: class_level_gains class_level_gains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_level_gains
    ADD CONSTRAINT class_level_gains_pkey PRIMARY KEY (class, level);


--
-- Name: class_skill_rates class_skill_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_skill_rates
    ADD CONSTRAINT class_skill_rates_pkey PRIMARY KEY (class, skill_type);


--
-- Name: class_spells class_spells_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_spells
    ADD CONSTRAINT class_spells_pkey PRIMARY KEY (class, spell_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (name);


--
-- Name: content_files content_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_files
    ADD CONSTRAINT content_files_pkey PRIMARY KEY (path);


--
-- Name: farm_plots farm_plots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farm_plots
    ADD CONSTRAINT farm_plots_pkey PRIMARY KEY (id);


--
-- Name: hero_backpack_slots hero_backpack_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_backpack_slots
    ADD CONSTRAINT hero_backpack_slots_pkey PRIMARY KEY (hero_id, slot_index);


--
-- Name: hero_backpack_slots hero_backpack_slots_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_backpack_slots
    ADD CONSTRAINT hero_backpack_slots_uq UNIQUE (hero_id, slot_index);


--
-- Name: hero_equipment hero_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_equipment
    ADD CONSTRAINT hero_equipment_pkey PRIMARY KEY (hero_id, slot);


--
-- Name: hero_last_pos hero_last_pos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_last_pos
    ADD CONSTRAINT hero_last_pos_pkey PRIMARY KEY (hero_id, map_key);


--
-- Name: hero_loot_drops hero_loot_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_loot_drops
    ADD CONSTRAINT hero_loot_drops_pkey PRIMARY KEY (id);


--
-- Name: hero_progress hero_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_progress
    ADD CONSTRAINT hero_progress_pkey PRIMARY KEY (hero_id);


--
-- Name: hero_training hero_training_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_training
    ADD CONSTRAINT hero_training_pkey PRIMARY KEY (hero_id);


--
-- Name: heroes_master heroes_master_heroKey_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heroes_master
    ADD CONSTRAINT "heroes_master_heroKey_key" UNIQUE ("heroKey");


--
-- Name: heroes_master heroes_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heroes_master
    ADD CONSTRAINT heroes_master_pkey PRIMARY KEY (id);


--
-- Name: items_master items_master_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items_master
    ADD CONSTRAINT items_master_key_key UNIQUE (key);


--
-- Name: items_master items_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items_master
    ADD CONSTRAINT items_master_pkey PRIMARY KEY (id);


--
-- Name: level_curve level_curve_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_curve
    ADD CONSTRAINT level_curve_pkey PRIMARY KEY (level);


--
-- Name: map_loot_items map_loot_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot_items
    ADD CONSTRAINT map_loot_items_pkey PRIMARY KEY (loot_id, item_key);


--
-- Name: map_loot map_loot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot
    ADD CONSTRAINT map_loot_pkey PRIMARY KEY (id);


--
-- Name: map_loot_spawns map_loot_spawns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot_spawns
    ADD CONSTRAINT map_loot_spawns_pkey PRIMARY KEY (id);


--
-- Name: map_objects map_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_objects
    ADD CONSTRAINT map_objects_pkey PRIMARY KEY (id);


--
-- Name: maps maps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maps
    ADD CONSTRAINT maps_pkey PRIMARY KEY (key);


--
-- Name: monster_instances monster_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monster_instances
    ADD CONSTRAINT monster_instances_pkey PRIMARY KEY (id);


--
-- Name: monsters_master monsters_master_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monsters_master
    ADD CONSTRAINT monsters_master_key_key UNIQUE (key);


--
-- Name: monsters_master monsters_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monsters_master
    ADD CONSTRAINT monsters_master_pkey PRIMARY KEY (id);


--
-- Name: player_hero_equips player_hero_equips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_hero_equips
    ADD CONSTRAINT player_hero_equips_pkey PRIMARY KEY (hero_id, slot);


--
-- Name: player_hero_skills player_hero_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_hero_skills
    ADD CONSTRAINT player_hero_skills_pkey PRIMARY KEY (hero_id, skill_type);


--
-- Name: player_hero_skills player_hero_skills_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_hero_skills
    ADD CONSTRAINT player_hero_skills_uniq UNIQUE (hero_id, skill_type);


--
-- Name: player_heroes player_heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_heroes
    ADD CONSTRAINT player_heroes_pkey PRIMARY KEY (id);


--
-- Name: player_inventories player_inventories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_inventories
    ADD CONSTRAINT player_inventories_pkey PRIMARY KEY (player_id, item_key);


--
-- Name: player_last_pos player_last_pos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_last_pos
    ADD CONSTRAINT player_last_pos_pkey PRIMARY KEY (player_id, map_key);


--
-- Name: player_online player_online_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_online
    ADD CONSTRAINT player_online_pkey PRIMARY KEY (hero_id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: skill_curves skill_curves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_curves
    ADD CONSTRAINT skill_curves_pkey PRIMARY KEY (skill_type, level);


--
-- Name: spawns spawns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns
    ADD CONSTRAINT spawns_pkey PRIMARY KEY (id);


--
-- Name: spells_master spells_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spells_master
    ADD CONSTRAINT spells_master_pkey PRIMARY KEY (id);


--
-- Name: sprites_master sprites_master_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_master
    ADD CONSTRAINT sprites_master_key_key UNIQUE (key);


--
-- Name: sprites_master sprites_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_master
    ADD CONSTRAINT sprites_master_pkey PRIMARY KEY (id);


--
-- Name: weapon_skill_map weapon_skill_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weapon_skill_map
    ADD CONSTRAINT weapon_skill_map_pkey PRIMARY KEY (weapon_type);


--
-- Name: xp_curves xp_curves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xp_curves
    ADD CONSTRAINT xp_curves_pkey PRIMARY KEY (level);


--
-- Name: xp_table xp_table_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xp_table
    ADD CONSTRAINT xp_table_pkey PRIMARY KEY (level);


--
-- Name: chat_scope_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_scope_id_idx ON public.chat_messages USING btree (scope, id DESC);


--
-- Name: hlp_map_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hlp_map_idx ON public.hero_last_pos USING btree (map_key);


--
-- Name: idx_chat_messages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_id ON public.chat_messages USING btree (id);


--
-- Name: idx_heroes_master_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_heroes_master_class ON public.heroes_master USING btree (class);


--
-- Name: idx_heroes_master_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_heroes_master_key ON public.heroes_master USING btree ("heroKey");


--
-- Name: idx_map_loot_items_loot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_map_loot_items_loot ON public.map_loot_items USING btree (loot_id);


--
-- Name: idx_map_loot_spawns_map_pos; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_map_loot_spawns_map_pos ON public.map_loot_spawns USING btree (map_key, x, y);


--
-- Name: idx_map_objects_mapkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_map_objects_mapkey ON public.map_objects USING btree ("mapKey");


--
-- Name: idx_monster_instances_map; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_monster_instances_map ON public.monster_instances USING btree (map_key);


--
-- Name: idx_monster_instances_spawn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_monster_instances_spawn ON public.monster_instances USING btree (spawn_id);


--
-- Name: idx_monster_instances_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_monster_instances_state ON public.monster_instances USING btree (state);


--
-- Name: idx_player_hero_skills_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_player_hero_skills_unique ON public.player_hero_skills USING btree (hero_id, skill_type);


--
-- Name: idx_player_heroes_playerid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_heroes_playerid ON public.player_heroes USING btree ("playerId");


--
-- Name: idx_player_last_pos; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_last_pos ON public.player_last_pos USING btree (player_id, map_key);


--
-- Name: idx_player_online_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_online_last_seen ON public.player_online USING btree (last_seen DESC);


--
-- Name: idx_spawns_mapkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spawns_mapkey ON public.spawns USING btree ("mapKey");


--
-- Name: idx_spawns_monster; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spawns_monster ON public.spawns USING btree ("monsterKey");


--
-- Name: ix_cf_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cf_path ON public.content_files USING btree (path);


--
-- Name: ix_csr_class_skill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_csr_class_skill ON public.class_skill_rates USING btree (class, skill_type);


--
-- Name: ix_hero_loot_drops_hero_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hero_loot_drops_hero_time ON public.hero_loot_drops USING btree (hero_id, created_at DESC);


--
-- Name: ix_hero_progress_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hero_progress_class ON public.hero_progress USING btree (class);


--
-- Name: ix_loot_hero_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loot_hero_time ON public.hero_loot_drops USING btree (hero_id, created_at DESC);


--
-- Name: ix_maps_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_maps_key ON public.maps USING btree (key);


--
-- Name: ix_mi_alive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mi_alive ON public.monster_instances USING btree (state, map_key);


--
-- Name: ix_mi_dead_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mi_dead_due ON public.monster_instances USING btree (state, respawn_at);


--
-- Name: ix_mi_spawn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mi_spawn ON public.monster_instances USING btree (spawn_id);


--
-- Name: ix_monster_instances_alive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_monster_instances_alive ON public.monster_instances USING btree (state, map_key);


--
-- Name: ix_phs_hero_skill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_phs_hero_skill ON public.player_hero_skills USING btree (hero_id, skill_type);


--
-- Name: ix_sc_skill_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_skill_level ON public.skill_curves USING btree (skill_type, level);


--
-- Name: ix_skill_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_skill_unique ON public.player_hero_skills USING btree (hero_id, skill_type);


--
-- Name: ix_skill_unique_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_skill_unique_ci ON public.player_hero_skills USING btree (hero_id, upper(skill_type));


--
-- Name: ix_spawns_map; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_spawns_map ON public.spawns USING btree ("mapKey");


--
-- Name: map_loot_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_loot_created_idx ON public.map_loot USING btree (created_at DESC);


--
-- Name: map_loot_map_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX map_loot_map_idx ON public.map_loot USING btree (map_key);


--
-- Name: mi_one_alive_per_spawn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mi_one_alive_per_spawn ON public.monster_instances USING btree (spawn_id) WHERE (state = 'ALIVE'::text);


--
-- Name: monster_instances_alive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monster_instances_alive_idx ON public.monster_instances USING btree (state);


--
-- Name: player_last_pos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX player_last_pos_idx ON public.player_last_pos USING btree (player_id, map_key);


--
-- Name: player_pos_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX player_pos_uidx ON public.player_positions USING btree ("playerId", mapkey);


--
-- Name: players_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX players_name_uq ON public.players USING btree (lower(name));


--
-- Name: uq_player_hero_skill; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_player_hero_skill ON public.player_hero_skills USING btree (hero_id, skill_type);


--
-- Name: monster_instances mi_fix_zero_xy_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mi_fix_zero_xy_ins BEFORE INSERT ON public.monster_instances FOR EACH ROW EXECUTE FUNCTION public.trg_mi_fix_zero_xy();


--
-- Name: monster_instances mi_fix_zero_xy_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mi_fix_zero_xy_upd BEFORE UPDATE ON public.monster_instances FOR EACH ROW WHEN (((new.x = 0) AND (new.y = 0))) EXECUTE FUNCTION public.trg_mi_fix_zero_xy();


--
-- Name: monster_instances mi_log_zero_xy_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mi_log_zero_xy_ins BEFORE INSERT ON public.monster_instances FOR EACH ROW EXECUTE FUNCTION public.trg_mi_log_zero_xy();


--
-- Name: monster_instances mi_log_zero_xy_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mi_log_zero_xy_upd BEFORE UPDATE ON public.monster_instances FOR EACH ROW EXECUTE FUNCTION public.trg_mi_log_zero_xy();


--
-- Name: monster_instances mi_set_xy_from_spawn; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mi_set_xy_from_spawn BEFORE INSERT ON public.monster_instances FOR EACH ROW EXECUTE FUNCTION public.trg_mi_set_xy_from_spawn();


--
-- Name: player_heroes player_heroes_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER player_heroes_touch BEFORE UPDATE ON public.player_heroes FOR EACH ROW EXECUTE FUNCTION public._touch_updatedat();


--
-- Name: player_positions player_positions_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER player_positions_touch BEFORE UPDATE ON public.player_positions FOR EACH ROW EXECUTE FUNCTION public._touch_updated_at();


--
-- Name: players players_set_updatedat; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER players_set_updatedat BEFORE UPDATE ON public.players FOR EACH ROW EXECUTE FUNCTION public.trg_players_set_updatedat();


--
-- Name: player_heroes trg_ensure_skills_after_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ensure_skills_after_insert AFTER INSERT ON public.player_heroes FOR EACH ROW EXECUTE FUNCTION public.tg_ensure_skills_after_hero_insert();


--
-- Name: items_master trg_items_master_sync_sprite; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_items_master_sync_sprite BEFORE INSERT OR UPDATE OF "dataJSON" ON public.items_master FOR EACH ROW EXECUTE FUNCTION public.items_master_sync_sprite();


--
-- Name: player_heroes trig_updated_at_player_heroes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trig_updated_at_player_heroes BEFORE UPDATE ON public.player_heroes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_generic();


--
-- Name: afk_boxes afk_boxes_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_boxes
    ADD CONSTRAINT afk_boxes_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: afk_inventories afk_inventories_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_inventories
    ADD CONSTRAINT afk_inventories_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: afk_workers afk_workers_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.afk_workers
    ADD CONSTRAINT afk_workers_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: farm_plots farm_plots_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farm_plots
    ADD CONSTRAINT farm_plots_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: monster_instances fk_mi_monster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monster_instances
    ADD CONSTRAINT fk_mi_monster FOREIGN KEY (monster_id) REFERENCES public.monsters_master(id) ON DELETE CASCADE;


--
-- Name: monster_instances fk_mi_spawn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monster_instances
    ADD CONSTRAINT fk_mi_spawn FOREIGN KEY (spawn_id) REFERENCES public.spawns(id) ON DELETE CASCADE;


--
-- Name: map_objects fk_mo_map; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_objects
    ADD CONSTRAINT fk_mo_map FOREIGN KEY ("mapKey") REFERENCES public.maps(key) ON DELETE CASCADE;


--
-- Name: spawns fk_spawns_map; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns
    ADD CONSTRAINT fk_spawns_map FOREIGN KEY ("mapKey") REFERENCES public.maps(key) ON DELETE CASCADE;


--
-- Name: hero_equipment hero_equipment_item_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_equipment
    ADD CONSTRAINT hero_equipment_item_key_fkey FOREIGN KEY (item_key) REFERENCES public.items_master(key);


--
-- Name: map_loot_items map_loot_items_item_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot_items
    ADD CONSTRAINT map_loot_items_item_key_fkey FOREIGN KEY (item_key) REFERENCES public.items_master(key);


--
-- Name: map_loot_items map_loot_items_loot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_loot_items
    ADD CONSTRAINT map_loot_items_loot_id_fkey FOREIGN KEY (loot_id) REFERENCES public.map_loot_spawns(id) ON DELETE CASCADE;


--
-- Name: map_objects map_objects_mapkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map_objects
    ADD CONSTRAINT map_objects_mapkey_fkey FOREIGN KEY ("mapKey") REFERENCES public.maps(key);


--
-- Name: player_inventories player_inventories_item_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_inventories
    ADD CONSTRAINT player_inventories_item_key_fkey FOREIGN KEY (item_key) REFERENCES public.items_master(key);


--
-- Name: spawns spawns_mapkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns
    ADD CONSTRAINT spawns_mapkey_fkey FOREIGN KEY ("mapKey") REFERENCES public.maps(key);


--
-- Name: spawns spawns_monsterkey_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns
    ADD CONSTRAINT spawns_monsterkey_fk FOREIGN KEY ("monsterKey") REFERENCES public.monsters_master(key);


--
-- PostgreSQL database dump complete
--

\unrestrict MBUa9Q7wx1rb8aw5pbqRbUTWcGSzP70UF9bJzdfPNTyzxK73l9ce012DlzLbtf5

