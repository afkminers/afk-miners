AFK Miners - Release Context Pack
Timestamp: 2025-08-22_214736
Name: auto
Commit: 868c050 | Branch: main | LastTag: v-am-2025-08-22-init
Depth: 4 | Symbols: True | Imports: True

Arquivos incluidos:
 - changes-since.txt
 - context-pack.txt
 - ctx.yml
 - data-summary.json
 - deps.txt
 - symbol-index.json
